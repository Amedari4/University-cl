<?php
session_start();
unset($_SESSION['foodlogin']);
header("location:../index.php");
?>
