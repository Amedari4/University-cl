<?php
error_reporting(E_ERROR);
$con=mysqli_connect("localhost","root","","clearance");
if($con)
{
	
}
else
{
	echo"database connectivity failed";
}
?>