<?php
session_start();
unset($_SESSION['studentlogin']);
header("location:../index.php");
?>
